const express = require('express');
const request = require("supertest");
const expect = require("chai").expect;

const app = express();

app.get('/first', (err, res) => {
    res.status(200).json({"ok":"response"})
})

describe("First Test", () =>{
    it("OK response", ()=>{
        request(app)
        .get("/first")
        .end((err, res) => {
            expect(res.statusCode).to.be.equal(200)
        })
    });

    it('Mocky OK Response', (done) => {
        request('http://www.mocky.io')
        .get('/v3/1e35a3b0-a330-4822-97f1-b23bca2b0ef5')
        .expect(200, done)
    })
})