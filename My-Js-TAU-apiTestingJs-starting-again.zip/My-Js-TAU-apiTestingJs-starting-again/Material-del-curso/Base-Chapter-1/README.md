# tau-api-testing

Training resource to be used alongside "API Testing with Supertest & Nock" on Test Automation University.

## Run Tests

```npm test```
